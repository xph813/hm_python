def send(text):

    print('sending message: %s' % text)