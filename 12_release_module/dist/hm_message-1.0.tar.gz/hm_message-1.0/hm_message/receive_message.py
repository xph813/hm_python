def receive():

    return "This a message from 100xx."